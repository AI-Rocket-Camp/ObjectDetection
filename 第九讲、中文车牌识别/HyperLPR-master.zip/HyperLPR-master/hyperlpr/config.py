import json



with open("/Users/universe/ProgramUniverse/zeusees/HyperLPR/config.json") as f:
    configuration = json.load(f)
