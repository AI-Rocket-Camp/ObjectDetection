from __future__ import division

import torch 
import torch.nn as nn
import torch.nn.functional as F 
from torch.autograd import Variable
import numpy as np
import cv2 

def unique(tensor):
    tensor_np = tensor.cpu().numpy()
    unique_np = np.unique(tensor_np)
    unique_tensor = torch.from_numpy(unique_np)
    
    tensor_res = tensor.new(unique_tensor.shape)
    tensor_res.copy_(unique_tensor)
    return tensor_res


def bbox_iou(box1, box2):
    """
    Returns the IoU of two bounding boxes 
    
    
    """
    #Get the coordinates of bounding boxes
    b1_x1, b1_y1, b1_x2, b1_y2 = box1[:,0], box1[:,1], box1[:,2], box1[:,3]
    b2_x1, b2_y1, b2_x2, b2_y2 = box2[:,0], box2[:,1], box2[:,2], box2[:,3]
    
    #get the corrdinates of the intersection rectangle
    inter_rect_x1 =  torch.max(b1_x1, b2_x1)
    inter_rect_y1 =  torch.max(b1_y1, b2_y1)
    inter_rect_x2 =  torch.min(b1_x2, b2_x2)
    inter_rect_y2 =  torch.min(b1_y2, b2_y2)
    
    #Intersection area
    inter_area = torch.clamp(inter_rect_x2 - inter_rect_x1 + 1, min=0) * torch.clamp(inter_rect_y2 - inter_rect_y1 + 1, min=0)

    #Union Area
    b1_area = (b1_x2 - b1_x1 + 1)*(b1_y2 - b1_y1 + 1)
    b2_area = (b2_x2 - b2_x1 + 1)*(b2_y2 - b2_y1 + 1)
    
    iou = inter_area / (b1_area + b2_area - inter_area)
    
    return iou

def predict_transform(prediction, inp_dim, anchors, num_classes, CUDA = True):

    #这里的prediction是检测层的特征图
    #第1个维度就是批量
    batch_size = prediction.size(0)
    #下采样倍数
    stride =  inp_dim // prediction.size(2)
    #风格数量,如416/32
    grid_size = inp_dim // stride
    #每个先验框预测的数量
    bbox_attrs = 5 + num_classes
    #总共的锚框的个数
    num_anchors = len(anchors)

    #对prediction进行维度变换，[1,255,13,13]-->[1,85x3,13x13]
    prediction = prediction.view(batch_size, bbox_attrs*num_anchors, grid_size*grid_size)
    print(prediction.shape)
    #变换：[1,255,169]-->[1,169,255]
    prediction = prediction.transpose(1,2).contiguous()
    print(prediction.shape)
    #变换：[1,169,255]-->[1,13x13x3,85]
    prediction = prediction.view(batch_size, grid_size*grid_size*num_anchors, bbox_attrs)
    print(prediction.shape)
    
    #anchors在特征图上的大小，共3个
    anchors = [(a[0]/stride, a[1]/stride) for a in anchors]
    print("三个锚框：")
    print(anchors)
    print("--------------------------")

    #对预测的中心坐标、目标置信度进行Sigmoid变换
    prediction[:,:,0] = torch.sigmoid(prediction[:,:,0])
    prediction[:,:,1] = torch.sigmoid(prediction[:,:,1])
    prediction[:,:,4] = torch.sigmoid(prediction[:,:,4])
    
    # 生成每个单元格左上角坐标，生成的坐标为grid x grid的二维数组
    # a，b分别对应这个网格矩阵x,y坐标对应的数组
    # 如当前的特征图13*13，则grid范围是[0,12]，x=[[0,1,...12],[0,1,...12]...]
    # y=[[0,0,...0],[1,1,...1],...,[12,12,...12]]
    grid = np.arange(grid_size)
    a,b = np.meshgrid(grid, grid)
    print("a第一行",a[0])
    print("b第一行",b[0])

    # 拉伸成一个列向量
    x_offset = torch.FloatTensor(a).view(-1,1)
    y_offset = torch.FloatTensor(b).view(-1,1)
    
    if CUDA:
        x_offset = x_offset.cuda()
        y_offset = y_offset.cuda()

    # 在第1个维度堆叠x_offset, y_offset，组成二维坐标，每个重复3次，因为有3个锚框
    # 比如有13个格子，刚x_y_offset的坐标就对应为(0,0),(0,1)…(12,12)
    # .view(-1, 2)将tensor变成两列，unsqueeze(0)在0维上添加了一维。
    x_y_offset = torch.cat((x_offset, y_offset), 1).repeat(1,num_anchors).view(-1,2).unsqueeze(0)
    #print(torch.cat((x_offset, y_offset), 1).repeat(1,num_anchors).view(-1,2))
    #print(torch.cat((x_offset, y_offset), 1).repeat(num_anchors,1))
    print("左上角坐标网格维度：",x_y_offset.shape)
    # 框相对中心坐标加上左上角坐标，得到绝对中心坐标
    prediction[:,:,:2] += x_y_offset

    # 对锚框的高和宽取对数
    anchors = torch.FloatTensor(anchors)

    if CUDA:
        anchors = anchors.cuda()

    # anchors本来是一个长度为3的列表，然后在行(0维)进行了13*13个复制，
    # 在列上没变化
    # unsqueeze(0)的作用是在数组上添加一维，这里是在第0维上添加的
    # 添加grid_size是为了之后的公式bw=pw×e^tw的tw。
    anchors = anchors.repeat(grid_size*grid_size, 1).unsqueeze(0)
    print("扩充后的锚框维度：",anchors.shape)
    
    # 对网络预测得到的矩形框宽高的偏移量进行指数计算，
    # 然后乘以锚框对应的宽高，
    # 这里的宽高对应最终特征图尺寸大小，
    # 得到物体方框的宽高
    # bw=pw*e^tw,bh=ph*e^th，锚框提供(ph,pw)。prediction为th,tw
    #print(prediction[:,:,2:4])
    prediction[:,:,2:4] = torch.exp(prediction[:,:,2:4])*anchors
    
    # 这里计算每个类别的得分，将网络预测的得分用sigmoid计算
    prediction[:,:,5: 5 + num_classes] = torch.sigmoid((prediction[:,:, 5 : 5 + num_classes]))

    # 将相对于最终特征图的方框坐标和尺寸映射回原始输入图片(416x416)，
    # 即将方框的坐标乘以网络的stride即可
    prediction[:,:,:4] *= stride
    print("边界框预测维度：",prediction.shape)
    return prediction

def write_results(prediction, confidence, num_classes, nms_conf = 0.4):
    '''
    prediction: 输入的预测维度(1,10647, 85)
    confidence:0.5
    num_classes:80
    '''
    print("非极大抑制准备：")
    conf_mask = (prediction[:,:,4] > confidence).float().unsqueeze(2)
    print("筛选器的维度:",conf_mask.shape)
    prediction = prediction*conf_mask
    print("筛选后预测的维度:",prediction.shape)
    
    # 创建一个新的数组，维度与predicton的维度相同
    box_corner = prediction.new(prediction.shape)
    # 框的左上角和右下角
    box_corner[:,:,0] = (prediction[:,:,0] - prediction[:,:,2]/2)
    box_corner[:,:,1] = (prediction[:,:,1] - prediction[:,:,3]/2)
    box_corner[:,:,2] = (prediction[:,:,0] + prediction[:,:,2]/2) 
    box_corner[:,:,3] = (prediction[:,:,1] + prediction[:,:,3]/2)
    prediction[:,:,:4] = box_corner[:,:,:4]
    
    batch_size = prediction.size(0)

    write = False
    

    # 每张图片的目标数量不一样，所以有效得分的方框的数量不一样，无法将几张图片同时处理，
    # 只能完成一张图的边界框目标得分筛选和NMS，
    # 所以必须在预测的第一个维度上（batch数量）上遍历每张图片，
    # 将得分低于一定分数的去掉，对剩下的方框进行进行NMS
    for ind in range(batch_size):
        image_pred = prediction[ind]          
      
        # 选择此一批中第ind个图像的预测结果,image_pred对应一张图片
        # 中所有方框的坐标(x1,y1,x2,y2)以及得分
        # 最大值的类别分数，prediction[:, 5:]表示每一分类的分数,
        # 返回每一行中所有类别的得分最高的那个类的得分max_conf，
        # 同时返回这个类对应的序号max_conf_score
        max_conf, max_conf_score = torch.max(image_pred[:,5:5+ num_classes], 1)
        print("最大得分维度：",max_conf.shape)

        # 维度扩展: shape=(10647,) => (10647,1)添加一个列的维度，
        # 变成二维张量，尺寸为10647x1
        max_conf = max_conf.float().unsqueeze(1)
        max_conf_score = max_conf_score.float().unsqueeze(1)
        
        # 移除每一行的80个类别分数，只保留bbox4个坐标以及objectnness分数，
        # 增加有最大值的类别分数及索引
        seq = (image_pred[:,:5], max_conf, max_conf_score)
        
        # 将每个方框的(x1,y1,x2,y2,s)与得分最高的这个类的分数max_conf和
        # 序号max_conf_score在列维度上连接起来，
        # 即将10647x5,10647x1,10647x1三个tensor 在列维度进行串接操作，
        # 得到一个10647x7的tensor,(x1,y1,x2,y2,s,s_cls,index_cls)。
        image_pred = torch.cat(seq, 1)
        print("方框、置信度、类别序号、类别分数维度：",image_pred.shape)

        # image_pred[:,4]是长度为10647的一维张量,
        # 假设有N个框含有目标的得分非0，返回Nx1的张量
        non_zero_ind =  (torch.nonzero(image_pred[:,4]))
        print("非零得分索引维度：",non_zero_ind.shape)
        print(image_pred[non_zero_ind.squeeze(),:].shape)
        try:
            image_pred_ = image_pred[non_zero_ind.squeeze(),:].view(-1,7)
        except:
            continue
        # 当没有检测到时目标时，我们使用 continue 来跳过对本图像的循环，即进行下一次循环
        if image_pred_.shape[0] == 0:
            continue       
#        
        img = cv2.imread("messi.jpg")
        img = cv2.resize(img, (416,416))
        box=image_pred_[:,:4]
                #print(box.shape)
        for f in box:
            c1 = tuple(f[0:2])
            c2 = tuple(f[2:4])
            draw_0 =cv2.rectangle(img, c1, c2,(0,0,255), 1)
            draw_0 =cv2.resize(draw_0,(1260,720))
            cv2.namedWindow("draw bounding box",cv2.WINDOW_AUTOSIZE);
            cv2.moveWindow("draw bounding box",0,0)
            #显示画过矩形框的图片
            cv2.imshow("draw bounding box", draw_0)
            cv2.waitKey(0)
        # 获取当前图像检测结果中出现的所有类别
        img_classes = unique(image_pred_[:,-1])  # -1 index holds the class index
        print("类别：",img_classes)
        
        print("NMS:")
        for cls in img_classes:

        
            # 获取含有该类别的预测数据
            print("**********************************")
            cls_mask = image_pred_*(image_pred_[:,-1] == cls).float().unsqueeze(1)
            print("预测当前物体类别{0}框的掩码：".format(cls))
            print(cls_mask)
            class_mask_ind = torch.nonzero(cls_mask[:,-2]).squeeze()
            print("预测当前物体类别{0}的框：".format(cls))
            print(class_mask_ind)
            image_pred_class = image_pred_[class_mask_ind].view(-1,7)
            
            # 开始NMS
            # 按置信度对含有该类别的预测框进行从大到小排序，并获取其下标

            conf_sort_index = torch.sort(image_pred_class[:,4], descending = True )[1]
            image_pred_class = image_pred_class[conf_sort_index]
            idx = image_pred_class.size(0)
             
            print(">>>>>>>类别{0}的预测框数{1}<<<<<<<".format(cls,idx))  
            for i in range(idx):
                #计算与当前具有最大置信度框的IOU
                print("-----------------------------------")
                try:
                    print("最大置信度框：",image_pred_class[i].unsqueeze(0))
                    ious = bbox_iou(image_pred_class[i].unsqueeze(0), image_pred_class[i+1:])
                except ValueError:
                    break
            
                except IndexError:
                    break
                
                print("其他与当前最大置信度框的IOU:\n",ious)
                # 选取IOU<阈值的框，也就是丢弃IOU>阈值的框
                iou_mask = (ious < nms_conf).float().unsqueeze(1)
               
                image_pred_class[i+1:] *= iou_mask 
                print("小于当前最大置信度，且大于0.4阈值的框被抑制：\n",image_pred_class[i+1:])      
            
                # 保留那些置信度非零的行数据
                non_zero_ind = torch.nonzero(image_pred_class[:,4]).squeeze()
                image_pred_class = image_pred_class[non_zero_ind].view(-1,7)
                print("抑制后剩下的框：\n",image_pred_class)

            
            # 将生成的张量所有元素填充为这些方框所属图片对应于batch中的序号ind
            # 1个类别可能有多个个体，用fill_(ind)实现    
            batch_ind = image_pred_class.new(image_pred_class.size(0), 1).fill_(ind)      #Repeat the batch_id for as many detections of the class cls in the image
            seq = batch_ind, image_pred_class
            
            # 将batch_ind, image_pred_class在列维度上进行连接，
            # image_pred_class每一行存储的是(x1,y1,x2,y2,s,s_cls,index_cls)，
            # 现在在第一列增加了一个代表这个行对应方框所属图片在一个batch中的序号ind
            if not write:
                output = torch.cat(seq,1)
                write = True
            else:
                out = torch.cat(seq,1)
                output = torch.cat((output,out))
            print("NMS结果：\n",output)

    try:
        return output
    except:
        return 0
    
def letterbox_image(img, inp_dim):
    '''resize image with unchanged aspect ratio using padding'''
    img_w, img_h = img.shape[1], img.shape[0]
    w, h = inp_dim
    new_w = int(img_w * min(w/img_w, h/img_h))
    new_h = int(img_h * min(w/img_w, h/img_h))
    resized_image = cv2.resize(img, (new_w,new_h), interpolation = cv2.INTER_CUBIC)
    
    canvas = np.full((inp_dim[1], inp_dim[0], 3), 128)

    canvas[(h-new_h)//2:(h-new_h)//2 + new_h,(w-new_w)//2:(w-new_w)//2 + new_w,  :] = resized_image
    
    return canvas

def prep_image(img, inp_dim):
    """
    Prepare image for inputting to the neural network. 
    
    Returns a Variable 
    """
    img = (letterbox_image(img, (inp_dim, inp_dim)))
    img = img[:,:,::-1].transpose((2,0,1)).copy()
    img = torch.from_numpy(img).float().div(255.0).unsqueeze(0)
    return img

def load_classes(namesfile):
    fp = open(namesfile, "r")
    names = fp.read().split("\n")[:-1]
    return names
